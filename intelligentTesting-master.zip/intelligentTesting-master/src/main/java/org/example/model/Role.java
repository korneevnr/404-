package org.example.model;

public enum Role {
    ADMIN,
    USER
}
